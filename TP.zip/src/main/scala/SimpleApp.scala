import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col


object SimpleApp {
  def main(args: Array[String]) {
    //arg(0) => temperature
    val spark = SparkSession.builder.appName("Simple Application").getOrCreate()
    val sc = spark.sparkContext
    import spark.implicits._

    val commune = args(0) // Should be some file on your system
    val dataCommune = spark.read.option("delimiter",";").option("header","true").csv(commune).select("DEPCOM","PTOT")
    dataCommune.show


    val insee = args(1) // Should be some file on your system
    val dataInsee = spark.read.option("delimiter",";").option("header","true").csv(insee).select("CODE INSEE","Code Dept","geom_x_y")
    dataInsee.show


    val posteSynop = args(2) // Should be some file on your system
    val dataPosteSynop = spark.read.option("delimiter",";").option("header","true").csv(posteSynop).select("ID","Latitude","Longitude")
    dataPosteSynop.show()
	
    val synopKelvin = args(3) // Should be some file on your system
    val dataSynopKelvin = spark.read.option("delimiter",";").option("header","true").csv(synopKelvin).select("t","date","numer_sta")
    dataSynopKelvin.show 


    def convertKtoC(df : DataFrame) : DataFrame= { 
	df.withColumn("t",col("t")-273.15)
    }

    import org.apache.spark.sql.functions.udf
    val dataSynopCelsius = convertKtoC(dataSynopKelvin)

    dataSynopCelsius.show

    spark.stop()
  }
}


